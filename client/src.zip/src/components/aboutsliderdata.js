import {
    im1,
    im2,
    im3,
    im4,
    im5,
    im6,
    im7,
    im8,
    im9,
    im10,
    im11,
    im12,
    im13,
  } from "../assets/img/images.js";
  
 const sliderPartenrs = [[im1, im2, im3, im4, im5, im6, im7, im8],[im9,im10,im11,im12,im13]];
 export default sliderPartenrs