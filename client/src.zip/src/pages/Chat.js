import React from 'react'

function Chat() {
  return (
    <div>
      Chat room page
    </div>
  )
}

export default Chat
